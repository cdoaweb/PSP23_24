/**
 * 
 */
package procesos_java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * @author gabriel
 *
 */
public class lecturaFlujoEntrada {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner in;
		/*BufferedReader entradaEstandar= new BufferedReader(new InputStreamReader(System.in));*/
		String mensaje;
		in = new Scanner(System.in);
		System.out.println("Escribe una cadena de texto \n");
		mensaje = in.nextLine();
		//mensaje = entradaEstandar.readLine();
		System.out.println("Mensaje introducido: "+ mensaje +"\n");
	}

}
