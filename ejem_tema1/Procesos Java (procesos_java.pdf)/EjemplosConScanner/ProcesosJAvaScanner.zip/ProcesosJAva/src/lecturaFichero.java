/**
 * 
 */
package procesos_java;

import java.io.*;
import java.util.Scanner;

/**
 * @author gabriel
 *
 */
public class lecturaFichero {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner in;
		// TODO Auto-generated method stub
		try {
			in = new Scanner(new File("fichero.txt"));
			while (in.hasNextLine()){
				System.out.println(in.nextLine());
			}
			/*BufferedReader reader = new BufferedReader(new FileReader("fichero.txt"));
			String linea = reader.readLine();
			while (linea != null) {
				System.out.println(linea);
				linea = reader.readLine();
			}
			reader.close();*/
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}
