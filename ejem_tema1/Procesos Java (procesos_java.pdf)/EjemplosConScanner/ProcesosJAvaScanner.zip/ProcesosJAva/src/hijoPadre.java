import java.io.*;
import java.util.Scanner;

public class hijoPadre {
    public static void main(String[] args) throws IOException {
        ProcessBuilder pb = new ProcessBuilder("ls","-l");

        Process p = pb.start();

        Scanner in;
        in = new Scanner(p.getInputStream());
        while (in.hasNextLine()){
            System.out.println(in.nextLine());
        }
        /*InputStreamReader ir = new InputStreamReader(p.getInputStream());
        BufferedReader br = new BufferedReader(ir);
        String linea;

        while ((linea = br.readLine())!= null){
            System.out.println(linea);
        }*/

    }
}
