import java.io.*;
import java.util.Scanner;

public class nslookupScanner {

    public static void main(String[] args) throws IOException {
        Scanner in;
        String linea;
        ProcessBuilder pb = new ProcessBuilder("nslookup");
        //envia la salida de datos del proceso a la salida estándar heredada
        pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);

        in = new Scanner(System.in);

        System.out.println("Introducir nombre de dominio");

        while (((linea = in.nextLine()) != null) && (linea.length() !=0)) {
            Process p = pb.start();
            try (PrintWriter out = new PrintWriter(p.getOutputStream())){
                System.out.println(linea);
                out.println(linea);
                out.flush();
            }
            try {
                p.waitFor();
            } catch (InterruptedException e) {}
            System.out.println("Introducir nombre de dominio");
        }
    }

}

