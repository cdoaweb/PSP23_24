/**
 * 
 */
package procesoEjecucion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * @author gabriel
 *
 */
public class ejecucionSimpleRuntime {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Runtime r = Runtime.getRuntime();
		
		Process p = r.exec("ls -l");
		File fich = new File("fichero2.txt");
	
		Scanner in;

		in = new Scanner (p.getInputStream());
		PrintWriter out = new PrintWriter(fich);
		while (in.hasNextLine()) {
			out.println(in.nextLine());
			out.flush();
		}
		out.close();
		//BufferedReader br = new BufferedReader(new InputStreamReader(out.getInputStream()));
		//String linea;
		//BufferedWriter bw = new BufferedWriter(new FileWriter(fich));
		
		/*while ((linea = br.readLine())!=null){
			bw.write(linea+"\n");
			System.out.println(linea);
		}
		
		bw.close();
		*/
	}

}
